# 멀티 AI Provider 지원 + 실행 모드 분리

## Summary

zyflow의 태스크 실행 시스템을 확장하여:
1. **다중 AI Provider 지원**: Claude 외에 Gemini, Codex, Qwen 등 지원
2. **실행 모드 분리**: 단일 실행(useAI)과 Swarm 실행(useSwarm)을 명확히 분리
3. 기존 CLI Adapter 구조를 활용하여 충돌 없이 통합

## Motivation

### 현재 상황
- **두 개의 실행 시스템 존재** (혼란 유발)
  - `useClaude` → `/api/claude/execute` → 단일 태스크
  - `useClaudeFlowExecution` → `/api/claude-flow/*` → Swarm 멀티에이전트
- Claude Code CLI만 지원
- `server/cli-adapter/`에 이미 6개 AI CLI 프로필 정의됨 (미사용)
- 모든 태스크가 Claude로만 실행되어 비용/성능 최적화 불가

### 목표
- **실행 모드 선택**: 단일 vs Swarm 명확히 구분
- **다중 Provider 지원**: 태스크 실행 시 AI 선택 가능
- **기존 구조 활용**: CLI Adapter 재사용
- **하위 호환성 유지**: 기존 useClaude 코드 변경 없이 동작

### 기대 효과
- **명확한 UX**: 단일/Swarm 모드 선택으로 비용 예측 가능
- **비용 절감**: 단순 태스크는 저렴한 모델 사용 (Gemini Flash, Haiku)
- **성능 최적화**: 대용량 컨텍스트는 Gemini Pro 활용 (100만 토큰)
- **확장성**: 새 AI CLI 추가 용이

## Scope

### In Scope
- **실행 모드 선택 UI**: 단일 실행 / Swarm 실행 탭
- **useAI 훅**: 다중 Provider 지원 단일 실행 훅
- **useSwarm 훅**: useClaudeFlowExecution 리네임 + 정리
- **useClaude 하위 호환**: useAI 래퍼로 유지
- **서버 API 확장**: `/api/ai/execute` 엔드포인트
- **Provider별 모델 옵션**: 동적 로드
- **CLI 가용성 체크**: 미설치 Provider 비활성화

### Out of Scope
- MCP Server 기반 통합 (문서 방식)
- 태스크 유형별 자동 라우팅 (v2)
- Consensus 패턴 - 다중 AI 합의 (v2)
- Swarm에 다중 Provider 지원 (v2)
- 커스텀 CLI 추가 UI

## Approach

### 아키텍처 (옵션 1: 분리 유지)

```
┌─────────────────────────────────────────────────────────────────┐
│                    TaskExecutionDialog                           │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌─────────────────────┐    ┌─────────────────────┐            │
│  │  ⚡ 단일 실행        │    │  🐝 Swarm 실행       │            │
│  │  (빠르고 저렴)      │    │  (멀티에이전트)      │            │
│  └──────────┬──────────┘    └──────────┬──────────┘            │
│             │                          │                        │
│             ▼                          ▼                        │
│  ┌─────────────────────┐    ┌─────────────────────┐            │
│  │ Provider 선택        │    │ Strategy 선택       │            │
│  │ Claude/Gemini/Codex │    │ Dev/Research/Test   │            │
│  └──────────┬──────────┘    └──────────┬──────────┘            │
│             │                          │                        │
│             ▼                          ▼                        │
│  ┌─────────────────────┐    ┌─────────────────────┐            │
│  │ Model 선택          │    │ Max Agents 설정     │            │
│  │ Haiku/Sonnet/Opus   │    │ 1-10                │            │
│  └─────────────────────┘    └─────────────────────┘            │
│                                                                  │
└──────────────────────────────┬───────────────────────────────────┘
                               │
           ┌───────────────────┴───────────────────┐
           │                                       │
           ▼                                       ▼
    ┌─────────────┐                        ┌─────────────┐
    │   useAI     │                        │  useSwarm   │
    │  (새 훅)    │                        │ (리네임)    │
    └──────┬──────┘                        └──────┬──────┘
           │                                       │
           ▼                                       ▼
    /api/ai/execute                        /api/claude-flow/*
           │                                       │
           ▼                                       ▼
    CLIProcessManager                      claude-flow@alpha
           │                                       │
           ▼                                       ▼
    claude | gemini | codex               npx claude-flow swarm
```

### 훅 구조

```typescript
// useAI - 단일 CLI 실행 (다중 Provider)
useAI()
├── provider: 'claude' | 'gemini' | 'codex' | 'qwen'
├── model: string
├── execute(params)
├── stop()
└── reset()

// useSwarm - Swarm 멀티에이전트 (Claude-Flow 전용)
useSwarm()
├── strategy: 'development' | 'research' | 'testing'
├── maxAgents: number
├── execute(params)
├── stop()
└── logs, progress

// useClaude - 하위 호환 래퍼
useClaude() = useAI({ provider: 'claude' })
```

### 구현 단계

#### Phase 1: 훅 리팩토링
1. `useAI` 훅 생성 - 다중 Provider 지원
2. `useClaude` → useAI 래퍼로 변경 (하위 호환)
3. `useClaudeFlowExecution` → `useSwarm` 리네임

#### Phase 2: 서버 API 확장
1. `/api/ai/execute` 엔드포인트 생성
2. CLI Adapter의 `CLIProcessManager` 연결
3. Provider별 프롬프트 형식 처리

#### Phase 3: UI 수정
1. TaskExecutionDialog에 실행 모드 탭 추가
2. 단일 모드: Provider + Model 선택
3. Swarm 모드: Strategy + MaxAgents 설정
4. CLI 가용성 체크 및 비활성화 표시

### 실행 모드 비교

| 구분 | 단일 실행 (useAI) | Swarm 실행 (useSwarm) |
|------|-------------------|----------------------|
| **용도** | 단일 파일 수정, 간단한 태스크 | 대규모 리팩토링, 복합 태스크 |
| **토큰** | 15-65K (저렴) | 50-200K+ (고비용) |
| **속도** | 빠름 (1-5분) | 느림 (10-30분) |
| **Provider** | Claude/Gemini/Codex/Qwen | Claude-Flow 전용 |
| **에이전트** | 1개 | 1-10개 |

### UI 디자인

```
┌─────────────────────────────────────────────────────┐
│ 태스크 실행                                          │
├─────────────────────────────────────────────────────┤
│                                                      │
│  ┌──────────────────┐ ┌──────────────────┐          │
│  │  ⚡ 단일 실행     │ │  🐝 Swarm 실행   │          │
│  │  ━━━━━━━━━━━━━━  │ │                  │          │
│  └──────────────────┘ └──────────────────┘          │
│                                                      │
│  ── AI Provider ──                                  │
│                                                      │
│  ┌─────────────────────────────────────────┐       │
│  │ 🤖 Claude                         [✓]   │       │
│  │    Anthropic Claude Code CLI            │       │
│  └─────────────────────────────────────────┘       │
│                                                      │
│  ┌─────────────────────────────────────────┐       │
│  │ 💎 Gemini                         [ ]   │       │
│  │    Google Gemini CLI (100만 토큰)       │       │
│  └─────────────────────────────────────────┘       │
│                                                      │
│  ┌─────────────────────────────────────────┐       │
│  │ 🧠 Codex                    [미설치]    │       │
│  │    OpenAI Codex CLI                     │       │
│  └─────────────────────────────────────────┘       │
│                                                      │
│  ── 모델 선택 (Claude) ──                           │
│                                                      │
│  ○ Haiku   - 빠르고 저렴 (단순 태스크)             │
│  ● Sonnet  - 균형 잡힌 성능 (권장)                 │
│  ○ Opus    - 최고 품질 (복잡한 태스크)             │
│                                                      │
│                    [ 실행 시작 ]                     │
│                                                      │
└─────────────────────────────────────────────────────┘
```

### 타입 정의

```typescript
// src/types/ai.ts

// 실행 모드
export type ExecutionMode = 'single' | 'swarm'

// AI Provider (단일 실행용)
export type AIProvider = 'claude' | 'gemini' | 'codex' | 'qwen' | 'kilo' | 'opencode'

// Provider 설정
export interface AIProviderConfig {
  id: AIProvider
  name: string
  icon: string
  enabled: boolean
  available: boolean  // CLI 설치 여부
  selectedModel: string
  availableModels: string[]
  order: number
}

// 단일 실행 파라미터
export interface AIExecuteParams {
  provider: AIProvider
  model: string
  changeId: string
  taskId: string
  taskTitle: string
  context?: string
}

// Swarm 실행 파라미터
export interface SwarmExecuteParams {
  strategy: 'development' | 'research' | 'testing'
  maxAgents: number
  changeId: string
  taskId?: string
  mode: 'full' | 'single' | 'analysis'
}
```

## Risks & Mitigations

| 리스크 | 완화 방안 |
|--------|----------|
| CLI 미설치 시 오류 | 실행 전 `which` 체크, 비활성 표시 |
| Provider별 출력 형식 차이 | 공통 파서 인터페이스 정의 |
| API 키 누락 | 환경변수 체크, 설정 안내 표시 |
| 기존 useClaude 호환성 | useClaude는 useAI wrapper로 유지 |
| 실행 모드 혼란 | 명확한 탭 UI + 비용 안내 표시 |
| Swarm 비용 예측 어려움 | 예상 토큰 범위 표시 |

## Dependencies

### 기존 코드 활용
- `server/cli-adapter/types.ts` - CLIProfile, CLIType 정의
- `server/cli-adapter/process-manager.ts` - CLIProcessManager
- `server/claude-flow/` - Swarm 실행 로직
- `.zyflow/cli-settings.json` - Provider 설정
- `src/hooks/useClaude.ts` - 기존 실행 로직 참고
- `src/hooks/useClaudeFlowExecution.ts` - Swarm 로직

### 새로 필요한 것
- Provider별 CLI 설치 (선택적)
  - `npm install -g @anthropic/claude-code`
  - `npm install -g @google/gemini-cli`
  - `npm install -g @openai/codex`

## Success Criteria

- [ ] 실행 모드 선택 UI (단일/Swarm 탭) 동작
- [ ] Claude 외 최소 1개 Provider (Gemini) 동작 확인
- [ ] TaskExecutionDialog에서 Provider 선택 가능
- [ ] Provider별 모델 선택 가능
- [ ] CLI 미설치 시 비활성화 표시
- [ ] cli-settings.json 기반 설정 반영
- [ ] 기존 useClaude 코드 하위 호환
- [ ] useSwarm으로 리네임 완료
- [ ] 실행 로그에 Provider/Model/Mode 정보 표시
